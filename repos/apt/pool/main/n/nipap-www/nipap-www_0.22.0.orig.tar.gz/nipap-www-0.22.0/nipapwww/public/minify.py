#!/usr/bin/python2.4

import httplib, urllib, sys

#print "Reading input from", sys.argv[1]
#f = open(sys.argv[1])
#js_code = f.read()
#f.close()
#
#js_code = "alert('hello');\nalert('bajs');";

params = urllib.urlencode([
    ('code_url', 'http://nipap-demo.spritelink.net/nipap.js'),
    ('compilation_level', 'SIMPLE_OPTIMIZATIONS'),
    ('output_format', 'text'),
    ('output_info', 'statistics'),
    ('language', 'ECMASCRIPT5'),
  ])

headers = { "Content-type": "application/x-www-form-urlencoded" }
conn = httplib.HTTPConnection('closure-compiler.appspot.com')
conn.request('POST', '/compile', params, headers)
response = conn.getresponse()
data = response.read()
print data
conn.close()

